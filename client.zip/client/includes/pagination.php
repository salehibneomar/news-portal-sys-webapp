<div class="paginetion">
    <ul>
        <!-- Next Button -->
        <li class="blog-prev">
            <a href=""><i class="fa fa-long-arrow-left"></i>  Previous</a>
        </li>
        <li><a href="">1</a></li>
        <li><a href="">2</a></li>
        <li class="active"><a href="">3</a></li>
        <li><a href="">4</a></li>
        <li><a href="">5</a></li>
        <!-- Previous Button -->
        <li class="blog-next">
            <a href=""> Next <i class="fa fa-long-arrow-right"></i></a>
        </li>
    </ul>
</div>