<?php

    $host = 'localhost';
    $user = 'root';
    $password = '';
    $database = 'admin_lte';

    $conn = mysqli_connect($host, $user, $password, $database);

    if(!$conn){
        die("<br><b>Error: </b>".mysqli_connect_error());
    }

?>